echo "noimp:0.8:noimp:noimp:noimp:noimp"
exit 0